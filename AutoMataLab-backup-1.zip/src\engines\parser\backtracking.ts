import { CFG, Production } from '../grammar/types';
import { ParserStatus, SyntaxTreeNode } from './ll1Simulation';

export class BacktrackingSimulation {
  public cfg: CFG;
  public input: string[] = [];
  public status: ParserStatus = 'idle';
  public errorMsg: string | null = null;
  public tree: SyntaxTreeNode | null = null;
  
  // UI Compatibility fields
  public stack: any[] = [];
  public inputIndex: number = 0;
  public derivationSteps: any[][] = [];
  
  // To prevent infinite loops with left-recursion
  // To prevent infinite loops with left-recursion and combinatorial explosion
  private maxDepth = 25;
  private maxOperations = 100000;
  private currentOperations = 0;
  
  constructor(cfg: CFG) {
    this.cfg = cfg;
  }

  public initialize(inputTokens: string[]) {
    this.input = inputTokens;
    this.status = 'running';
    this.errorMsg = null;
    this.errorMsg = null;
    this.currentOperations = 0;
    
    // We just execute the entire parse synchronously for backtracking,
    // since building a step-by-step state machine for recursive descent is highly complex.
    // The "step" function will just compute the result.
  }

  public step(): boolean {
    if (this.status !== 'running') return false;
    
    if (!this.cfg.startSymbol) {
      this.status = 'rejected';
      this.errorMsg = 'No start symbol defined.';
      return true;
    }
    
    const result = this.parse(this.cfg.startSymbol, 0, 0);
    
    if (result && result.index === this.input.length) {
      this.status = 'accepted';
      this.tree = result.node;
    } else {
      this.status = 'rejected';
      if (this.currentOperations > this.maxOperations) {
        this.errorMsg = 'Parse aborted: Combinatorial explosion detected. The grammar is too ambiguous or left-recursive for recursive descent. Try parsing a shorter string or optimizing the grammar (e.g. Left Factoring / Eliminating Left Recursion).';
      } else {
        this.errorMsg = 'Could not parse the entire input. The string is not in the language or the parser hit a depth limit.';
      }
    }
    
    return true;
  }
  
  private parse(symbol: string, index: number, depth: number): { index: number, node: SyntaxTreeNode } | null {
    if (depth > this.maxDepth) return null; // Abort on deep recursion (e.g. left recursion)
    
    this.currentOperations++;
    if (this.currentOperations > this.maxOperations) {
      return null; // Abort on combinatorial explosion
    }
    
    if (this.cfg.terminals.has(symbol)) {
      if (index < this.input.length && this.input[index] === symbol) {
        return {
          index: index + 1,
          node: { id: Math.random().toString(), symbol, children: [], isMatched: true }
        };
      }
      return null;
    }
    
    // Epsilon
    if (symbol === 'ε') {
      return {
        index,
        node: { id: Math.random().toString(), symbol, children: [], isMatched: true }
      };
    }
    
    if (this.cfg.nonterminals.has(symbol)) {
      const prods = this.cfg.productions.filter(p => p.lhs === symbol);
      
      for (const p of prods) {
        let currentIndex = index;
        const children: SyntaxTreeNode[] = [];
        let success = true;
        
        const rhs = p.rhs.length > 0 ? p.rhs : ['ε'];
        
        for (const sym of rhs) {
          const res = this.parse(sym, currentIndex, depth + 1);
          if (res) {
            currentIndex = res.index;
            children.push(res.node);
          } else {
            success = false;
            break;
          }
        }
        
        if (success) {
          return {
            index: currentIndex,
            node: { id: Math.random().toString(), symbol, children }
          };
        }
      }
    }
    
    return null;
  }
}
