# AutomataLab Architecture Document

This document outlines the high-level architecture, design philosophy, core abstractions, and technical roadmap for AutomataLab. It acts as a living document to guide future development and help contributors orient themselves.

## 1. Design Philosophy

AutomataLab is built on the core principle of **strict separation of concerns**. 
- **Engines are Pure:** The theoretical logic of automata (simulators, parsers, converters) resides in pure TypeScript, entirely agnostic of the UI, DOM, or React. 
- **UI is Presentation:** The React frontend handles rendering, state hydration, and user interactions. 
- **Algorithms over Abstractions:** We prefer explicit algorithm implementations (e.g., explicit subset construction, Moore's minimization) over deep object-oriented hierarchies or "magic" generic frameworks.
- **Explicit Type-Gating:** Instead of loose duck typing, we rely on discriminated unions (`MachineType`) and specific interfaces to define boundaries between different classes of automata (e.g., DFA vs. Pushdown Automata vs. Turing Machines).

*(See `principles.md` for a complete list of project principles).*

## 2. Current Architecture

The application follows a predictable, three-tier architecture with a specialized workspace router:

### A. The Shell Tier (`src/components/layout/` & `src/components/workspaces/`)
A hash-based router in `App.tsx` directs users to specialized ergonomic shells based on the academic subject matter:
- **`WorkspaceHub` (`#/`)**: The Wireshark-inspired landing page that routes users to specific tools and handles anti-trap logic (ensuring machines don't open in the wrong workspace).
- **`MachineWorkspace` (`#/machine`)**: The infinite canvas and simulation controls for Finite Automata, PDAs, and TMs.
- **`GrammarWorkspace` (`#/grammar`)**: A split-view IDE layout featuring a raw text editor for context-free grammars alongside a dense Analysis Dashboard (FIRST/FOLLOW sets, Nullable variables, Ambiguity detection).
- **`ParserWorkspace` (`#/parser`)**: A compiler-debugger layout featuring live Parsing Matrices (LL/LR), a Parser execution tracker (Stack & Input Buffer), and the dynamic Parse Tree builder.

### B. The Engine Tier (`src/engines/` & `src/modules/`)
Contains all computational logic, definitions, and algorithms.
- **Math Utils (`engines/core/graph/`):** Shared mathematical graph theory primitives (Tarjan's SCC, BFS/DFS, Epsilon Closures) decoupling structural operations from Automata logic.
- **Plugins (`plugins/core/`):** Standardized interfaces for defining algorithms, analysis, and conversions to allow declarative injection.
- **Modules (`modules/parser/`):** Deeply scoped subsystems (like the Parser Module) separating algorithms, execution, and components from the main application.
Contains all computational logic, definitions, and algorithms.
- **Core Types:** Defines the foundational interfaces (`MachineDefinition`, `State`, `Transition`, `MachineType`).
- **Simulators:** Isolated directories for each machine type (`dfa/`, `pda/`, `tm/`, etc.). Each contains an `Engine` class or function that computes step-by-step execution states (the "Computation Tree").
- **Conversions:** Contains pure functions that transform one `MachineDefinition` into another (e.g., `nfaToDfa`, `minimizeDfa`) or construct machines from text (`regexToNfa`, `cfgToPda`).
- **Validation:** Functions to ensure machine definitions satisfy theoretical requirements before execution.
- **Analysis (`engines/core/analysis.ts` & `engines/workers/analysis.worker.ts`):** Implements structural analysis algorithms (Reachability, Emptiness, Equivalence, Inclusion). In order to maintain 60 FPS UI performance, heavy computations are offloaded to a background Web Worker using Vite's `?worker` query.

### C. The State Management Tier (`src/store/`)
Uses `zustand` to bridge the Engine Tier and the UI Tier.
- **`documentStore`:** The unified domain store containing machine, grammar, and parser slices. Replaces the fragmented `machineStore`, `grammarStore`, and `parserStore` with a single, coherent academic document root.
- **`workspaceStore`:** Manages transient workspace UI state (e.g., active selection, clipboard, local focus) across the active tab. Replaces legacy `uiStore` overlaps.
- **`tabStore`:** A newly extracted state manager (Phase E) responsible strictly for multi-tab logic: maintaining active tabs, routing between them, and tracking dirty/unsaved states.
- **`machineStore`:** Focuses exclusively on the internal execution and topology of the *currently active machine*. It is intentionally decoupled from tab routing. It relies on granular Immer patches (`produceWithPatches`) to maintain its state without mutating history directly.
- **`historyStore`:** A new workspace-agnostic History Service that maintains isolated `past` and `future` Patch stacks mapped by `tabId`. It exposes universal `undo()` and `redo()` actions bound to global shortcuts.
- **`simulationStore`:** Manages the active execution state (e.g., stepping through an input string, tracking the computation tree, current active nodes).
- **`uiStore`:** Restricted specifically to global UI state (modal visibility, current theme, and global clipboard).
- **`useSelectionStore` (Phase 6):** A global event bus connecting workspaces. It tracks the currently selected Grammar Rule or Semantic Action, instantly syncing highlights across the Dependency Graph, the Parse Table, and the Item Set Automaton to create true IDE cohesion.
- **`commandStore`:** Acts as a lightweight command bus to pass imperative commands (like zooming or specific canvas manipulations) from the menu bar to the active canvas instance.

### D. The UI Tier (`src/components/`, `src/hooks/`, `src/services/`)
A React-based presentation layer.
- **Canvas (`components/canvas/`)**: Uses `xyflow` (React Flow) for interactive graph visualization. Interactions are extracted into modular hooks.
- **Services (`src/services/`):** Contains provider-based utilities like `ExportService`, which generates SVG, renders high-res PNG Blobs, and serializes JSON directly to the user's Clipboard, bypassing clunky modals.
- **Editors (`components/canvas/editors/`)**: Type-specific transition forms (e.g., `FiniteAutomataEditor`, `TMEditor`) dispatched by a central `TransitionEditor` modal.
- **Conversions (`components/conversions/`)**: A plugin-style registry (`conversionsRegistry.tsx`) powers the conversions modal.
- **Analysis (`components/analysis/`)**: Houses `AnalysisModal.tsx`, which manages asynchronous communication with the background Web Worker.

## 3. Core Abstractions

### `MachineDefinition`
The universal serializable object representing any automaton in the system.
```typescript
interface MachineDefinition {
  id: string;
  type: MachineType; // 'DFA' | 'NFA' | 'ENFA' | 'DPDA' | 'NPDA' | 'TM' | 'LBA'
  states: State[];
  transitions: Transition[];
  // Extensible fields depending on the type:
  tapeCount?: number;
  blankSymbol?: string;
}
```

### `Transition`
A flat, flexible object representing an edge in the graph. It relies on optional properties that are strictly validated based on the `MachineType`.
- **FA:** Uses `symbols` array.
- **PDA:** Uses `read`, `pop`, `push`.
- **TM:** Uses arrays `reads`, `writes`, `directions` mapped by tape index.

### `ComputationTree`
Because non-deterministic machines (NFAs, NPDAs, TMs) branch, the simulation engine returns a tree of configurations rather than a linear history. The UI traverses this tree to display active execution frontiers.

## 4. Engine Responsibilities

- **Immutability:** Engines treat `MachineDefinition` as immutable. All transformations yield a new machine object.
- **Deterministic Traversal:** Even for non-deterministic machines, the engine must produce deterministic, reproducible computation trees.
- **Self-Contained Validation:** Engines do not rely on the UI to sanitize inputs. They throw clear, descriptive errors when fed invalid state machines.
- **Runtime Integrity (`invariant`):** All mathematical functions and state mutations enforce strict assumptions using the `invariant()` utility. Failures immediately throw rather than propagating corrupt state, acting as the foundation of our fail-fast architecture.
- **Resource Protection Budgets:** Algorithms prone to exponential explosion (e.g. $\epsilon$-closures, Subset Construction, $FIRST$/$FOLLOW$ generation, LR closures) are protected by a strict `MAX_COMPUTATION_ITERATIONS` budget (e.g. 50,000) that prevents infinite loops and browser lockups.
- **Execution History:** Engines must track their internal state efficiently (often via bounded snapshotting) to support backward-stepping without memory leaks.

## 5. Known Technical Debt

- **React Flow Render Thrashing:** While custom hooks have organized the logic, the canvas still triggers frequent re-renders when dragging nodes. *Optimization achieved:* `StateNode.tsx` uses targeted Zustand store selectors (`s => s.analysisHighlights[id]`) instead of destructuring the whole store, preventing massive O(N^2) render cascades.
- **Graph Layout Performance:** The `applyAutoLayout` utility (using ELK.js) handles initial arrangements well but struggles to maintain "mental map" stability during live conversions.
- **Serialization Formats:** The app natively supports both our custom `.autolab.json` format and standard JFLAP 7.1 `.jff` XML files, improving interoperability across educational tools.
- **Ergonomics Audit Pending:** A full human ergonomics audit (Headless Chrome / Playwright) was initiated on 2026-06-24 but blocked by sandbox network isolation. Must be re-run interactively or with `--host` flag. Workflows pending: Grammar → FIRST/FOLLOW → Parser → Parse, Regex → NFA → DFA → Minimize, Machine → Simulate → Convert → Export.

## 6. Future Plans

- **Regex & Grammar Integration:** Expand text-to-machine capabilities. Build visual parsers that step through CYK algorithms for CFGs.
- **Advanced Machine Types:** Explore adding Mealy/Moore machines, Petri Nets, or Register Machines.

## 7. Landing Page
The marketing landing page is built as a self-contained static site inside the `page/` directory.
- **Pure Web Standards**: Built entirely with Vanilla HTML, CSS, and JS. It avoids React and Tailwind to maintain total control over design tokens and motion.
- **Unified Motion System**: CSS transitions and animations are controlled by strict variables (`--lp-ease`, `--lp-duration`) for fluid, hardware-accelerated animations.
- **Scroll Handling & Scroll Spy**: Uses `Lenis` (via `script.js`) to provide an ultra-smooth, inertial scrolling experience. An `IntersectionObserver` handles scroll spy tracking to highlight the active section link in the navigation header.
- **Scroll Entrance Animations**: A secondary `IntersectionObserver` tracks elements (e.g. features, downloads, stats) as they cross into the viewport and adds `.in-view` classes to trigger smooth fade-and-slide CSS animations.
- **Dynamic Release Asset Fetching & Integrity Verification**: Queries the public GitHub Releases API (`/releases/latest`) on page load to dynamically parse version tags, lookup file sizes, bind direct download URLs, and extract platform-specific SHA-256 checksums from the release body description. If hashes are found in the release description, they dynamically override the default static HTML placeholders.
- **Micro-Interactions & Parallax**: 
  - **Spotlight Grid Hover**: A JavaScript pointer tracker calculates mouse offsets relative to bento grid cards and sets `--mouse-x` and `--mouse-y` variables, allowing a responsive CSS radial gradient spotlight to follow the cursor.
  - **Ambient Parallax**: A background listener shifts the backdrop glow element (`.lp-ambient-glow`) by 5% towards the cursor coordinates to give a premium, organic depth.
- **Wiki-Driven Documentation**: The landing page documentation cards no longer duplicate markdown into the web bundle. Instead, they route users directly to the official GitHub Wiki repository pages (`Architecture.md`, `File-Format.md`, `Decision-Log.md`, `Contributing-Guide.md`), ensuring there is a single source of truth.
- **Dual Vercel Deployment**: The web presence is split across two distinct Vercel domains for clean separation of concerns:
  - `automata-lab-one.vercel.app`: Hosts the public marketing landing page.
  - `automata-lab-sim.vercel.app`: Hosts the actual React/TypeScript simulation engine (bypassing landing page routes via `/#/app`).


## Security & Deployment Architecture
- **Vercel Static Deployment:** The landing page enforces a strict Content-Security-Policy via ercel.json, restricting inline scripts and limiting connections to the GitHub API.
- **Simulator Demo Architecture:** The core React web app utilizes a build-time environment variable (VITE_SIMULATOR_MODE) to structurally strip out desktop-exclusive features (MenuBar, File Saving, Exports) on Vercel deployments, preventing URL-based bypassing of the demo restrictions.

## 8. Phase 3 and Phase 4 Architectural Extensions

- **Phase 3 (Grammar and CFG):** Built text-based parsers mapping string definitions to `Grammar` ASTs. Added exhaustive bounded search logic for ambiguity detection and sequential deterministic IDs for parse forest components.
- **Phase 4 (Parsing Studio):** Extended the `Automaton` engine interface so the core simulation capabilities (time travel, slider, step logging) work dynamically for Table-Driven parsers without touching UI code. LL(1) uses `LL1ParseTable` (string mapping) whilst LR parsers utilize standard numeric DFAs via `ParsingEngine.ts`.
  


### Recent Architectural Adjustments
- **Workspace-Agnostic History (Release 7.1):** Transitioned away from snapshot-based `past`/`future` arrays inside `machineStore`. We now use `immer` `produceWithPatches` to stream fine-grained delta patches to a global `HistoryService`, vastly reducing memory overhead and DOM thrashing during Undo/Redo.
- **JFLAP Interoperability (Release 7.1):** Native integration of `.jff` XML parsing and serialization (`jflapParser` / `jflapSerializer`), available directly via the "Open File" Workspace Hub tile and the Export Modal.
- **Cross-Panel Traceability (Phase 6):** Introduced `DependencyGraphCanvas` in the Grammar Lab and the interactive `ConflictInspector` in the Parser Studio, replacing isolated passive warnings with highly educational, interactive debugging workflows.
- **Robustness Audit Remediations (Phase E):** Separated the `machineStore` god-object into `tabStore` and `machineStore`, added paginated/virtualized views for exploding parse tables, hardened JFLAP DOM parsing against XXE attacks, and stabilized graph topologies against `elk.js` layout collisions.
- **State Integrity Hardening Sprint (2026-06-24):** Resolved five P0/P1 bugs: history memory leak on tab close (D109), stale UI selection across tab switches (D110–D112), JFLAP import crash on malformed transition references (D113), and Parser Studio silent crash on unexpected grammar parse errors (D114).
- **UI/UX Resizability & Collision Standardisation (2026-06-25):** Implemented a generic Splitter component for flexible viewports across workspaces, standardized LR parsing S/R conflict resolution to align with Yacc/Bison, and added strict tab route mapping to prevent workspace tool cross-contamination.
- **Quality Engineering Hardening Sprint (2026-06-25):** Transitioned the project focus to a structural hardening epic focusing on static analysis, runtime invariants, fuzz testing, and strict test-driven development.
- **Parser Studio Finalization (2026-06-25):** Fully decoupled Parser state generation via `useParserData`, upgraded AST rendering to `mrtree` for rigorous left-to-right sibling ordering, implemented Maximal Munch for string tokenization in the Lexer, implemented standardized parsing table & automaton serialization capabilities, and permanently resolved the App.tsx hash-routing race condition that previously hijacked navigation flows.
- **Edge Routing Engine (2026-06-26):** Implemented a `GlobalRoutingEngine` (`modules/parser/layout/GlobalRoutingEngine.ts`) using A* pathfinding with obstacle inflation for the LR automaton visualization. Routes travel around state nodes instead of through them. Parallel lane separation prevents overlapping edges. Two-mode architecture: interactive mode (reroute only connected edges during drag) and final mode (global reroute on drop) to prevent O(n²) sluggishness (D125). Added `useGlobalRouting.ts` hook to manage routing lifecycle. Fixed cross-edge toggle in `LRLayoutStrategy.ts` to filter by `edgeClass === 'tree'` (D129).
- **Parser Engine Data Flow (2026-06-26, documented):** The parser simulation has a critical property name mapping chain: `ParsingEngine.createStepResult()` returns `stack: string[]` → `useSimulation.applyEngineResult()` maps it as `activeStack: result.stack` → `simulationStore.applyStepResult()` stores it as `activeStack` (D130). **KNOWN ISSUE (D126):** The parse table is built twice independently — once for UI display (`useParserData.ts`) and once for engine simulation (`engineFactory.ts`). This is fragile and should be refactored to share a single table instance.
