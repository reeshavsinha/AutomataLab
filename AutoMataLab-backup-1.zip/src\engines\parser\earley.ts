import { CFG, Production } from '../grammar/types';
import { ParserStatus } from './ll1Simulation';

export interface EarleyItem {
  lhs: string;
  rhs: string[];
  dot: number;
  origin: number;
}

export class EarleySimulation {
  public cfg: CFG;
  public input: string[] = [];
  public stateSets: EarleyItem[][] = [];
  public status: ParserStatus = 'idle';
  public errorMsg: string | null = null;
  
  public currentSetIndex = 0;
  public currentItemIndex = 0;
  
  // UI Compatibility fields
  public stack: any[] = [];
  public tree: any = null;
  public inputIndex: number = 0;
  public derivationSteps: any[][] = [];
  
  constructor(cfg: CFG) {
    this.cfg = cfg;
  }

  public initialize(inputTokens: string[]) {
    this.input = inputTokens;
    this.status = 'running';
    this.errorMsg = null;
    
    // Add dummy start state S' -> S
    const startSymbol = this.cfg.startSymbol;
    this.stateSets = Array.from({ length: this.input.length + 1 }, () => []);
    
    if (startSymbol) {
      this.stateSets[0].push({
        lhs: "S'",
        rhs: [startSymbol],
        dot: 0,
        origin: 0
      });
    }

    this.currentSetIndex = 0;
    this.currentItemIndex = 0;
  }
  
  private addItem(setIndex: number, item: EarleyItem): boolean {
    const set = this.stateSets[setIndex];
    const exists = set.some(existing => 
      existing.lhs === item.lhs &&
      existing.dot === item.dot &&
      existing.origin === item.origin &&
      existing.rhs.join(' ') === item.rhs.join(' ')
    );
    
    if (!exists) {
      set.push(item);
      return true;
    }
    return false;
  }

  public step(): boolean {
    if (this.status !== 'running') return false;
    
    const n = this.input.length;
    
    if (this.currentSetIndex > n) {
      // Done processing all sets
      this.checkAcceptance();
      return true;
    }

    const currentSet = this.stateSets[this.currentSetIndex];
    
    if (this.currentItemIndex < currentSet.length) {
      const item = currentSet[this.currentItemIndex];
      const nextSymbol = item.rhs[item.dot];

      if (item.dot >= item.rhs.length) {
        // COMPLETER
        const originSet = this.stateSets[item.origin];
        for (const originItem of originSet) {
          if (originItem.dot < originItem.rhs.length && originItem.rhs[originItem.dot] === item.lhs) {
            this.addItem(this.currentSetIndex, {
              lhs: originItem.lhs,
              rhs: originItem.rhs,
              dot: originItem.dot + 1,
              origin: originItem.origin
            });
          }
        }
      } else if (this.cfg.nonterminals.has(nextSymbol)) {
        // PREDICTOR
        const prods = this.cfg.productions.filter(p => p.lhs === nextSymbol);
        for (const p of prods) {
          this.addItem(this.currentSetIndex, {
            lhs: p.lhs,
            rhs: p.rhs.length > 0 && p.rhs[0] !== 'ε' ? p.rhs : [],
            dot: 0,
            origin: this.currentSetIndex
          });
        }
      } else {
        // SCANNER
        if (this.currentSetIndex < n) {
          const token = this.input[this.currentSetIndex];
          if (nextSymbol === token) {
            this.addItem(this.currentSetIndex + 1, {
              lhs: item.lhs,
              rhs: item.rhs,
              dot: item.dot + 1,
              origin: item.origin
            });
          }
        }
      }
      
      this.currentItemIndex++;
      return true;
    } else {
      // Finished current set
      this.currentSetIndex++;
      this.currentItemIndex = 0;
      
      if (this.currentSetIndex > n) {
        this.checkAcceptance();
      }
      return true;
    }
  }
  
  private checkAcceptance() {
    const finalSet = this.stateSets[this.input.length];
    const accepted = finalSet?.some(item => 
      item.lhs === "S'" && item.dot === 1 && item.origin === 0
    );
    this.status = accepted ? 'accepted' : 'rejected';
  }
}
