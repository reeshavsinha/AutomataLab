// src/engines/parser/lrSimulation.ts

import { CFG, EOF_SYMBOL, EPSILON } from '../grammar/types';
import { LR0Table, ActionEntry } from './lr0';
import { SyntaxTreeNode, ParserStatus } from './ll1Simulation';

export type LRStackItem = number | SyntaxTreeNode;

export class LRSimulation {
  private cfg: CFG;
  private table: LR0Table;
  private nextId = 1;
  
  public input: string[];
  public inputIndex: number = 0;
  public stack: LRStackItem[] = [];
  public tree: SyntaxTreeNode | null = null;
  public status: ParserStatus = 'idle';
  public errorMsg: string | null = null;
  public derivationSteps: string[][] = [];

  constructor(cfg: CFG, table: LR0Table) {
    this.cfg = cfg;
    this.table = table;
    this.input = [];
  }

  public initialize(inputTokens: string[]) {
    this.input = [...inputTokens, EOF_SYMBOL];
    this.inputIndex = 0;
    this.status = 'running';
    this.errorMsg = null;
    this.nextId = 1;
    this.tree = null;
    
    // Stack starts with state 0
    this.stack = [0];
    this.derivationSteps = [];
    this.recordDerivationStep();
  }

  private recordDerivationStep() {
    const stackSymbols = this.stack.filter(item => typeof item === 'object').map((n: any) => n.symbol as string).filter(s => s !== EPSILON);
    const remainingInput = this.input.slice(this.inputIndex).filter(s => s !== EOF_SYMBOL);
    const form = [...stackSymbols, ...remainingInput];
    
    if (this.derivationSteps.length === 0) {
      if (form.length > 0) this.derivationSteps.push(form);
    } else {
      const last = this.derivationSteps[this.derivationSteps.length - 1];
      if (last.join(' ') !== form.join(' ')) {
        this.derivationSteps.push(form);
      }
    }
  }

  public step(): boolean {
    if (this.status !== 'running') return false;
    
    const currentState = this.stack[this.stack.length - 1] as number;
    const currentToken = this.input[this.inputIndex];

    const actionCell = this.table.actionTable.get(currentState)?.get(currentToken);
    
    if (!actionCell || actionCell.length === 0) {
      this.status = 'rejected';
      this.errorMsg = `Parse Error: No action defined for State ${currentState} on terminal '${currentToken}'`;
      return true;
    }
    
    if (actionCell.length > 1) {
      this.status = 'error';
      this.errorMsg = `Parse Error: Conflict detected at State ${currentState} on terminal '${currentToken}'`;
      return true;
    }

    const action = actionCell[0];

    if (action.type === 'Shift') {
      const targetState = action.target!;
      
      const leafNode: SyntaxTreeNode = {
        id: `node_${this.nextId++}`,
        symbol: currentToken,
        children: [],
        isMatched: true
      };
      
      this.stack.push(leafNode);
      this.stack.push(targetState);
      this.inputIndex++;
      return true;
    }

    if (action.type === 'Reduce') {
      const prodIndex = action.target!;
      const prod = this.table.augmentedCfg.productions[prodIndex];
      
      const rhsLength = prod.rhs.length === 1 && prod.rhs[0] === EPSILON ? 0 : prod.rhs.length;
      const elementsToPop = 2 * rhsLength;
      
      const children: SyntaxTreeNode[] = [];
      
      // Pop elements (state, symbol) pairs
      for (let i = 0; i < rhsLength; i++) {
        this.stack.pop(); // pop state
        const symbolNode = this.stack.pop() as SyntaxTreeNode; // pop symbol
        children.unshift(symbolNode); // add to front so order is preserved
      }
      
      if (rhsLength === 0) {
        // Epsilon production, add an epsilon node
        children.push({
          id: `node_${this.nextId++}`,
          symbol: EPSILON,
          children: [],
          isMatched: true
        });
      }

      const parentNode: SyntaxTreeNode = {
        id: `node_${this.nextId++}`,
        symbol: prod.lhs,
        children: children
      };

      const topState = this.stack[this.stack.length - 1] as number;
      const gotoTarget = this.table.gotoTable.get(topState)?.get(prod.lhs);

      if (gotoTarget === undefined || gotoTarget === -1) {
        this.status = 'error';
        this.errorMsg = `Parse Error: No GOTO defined for State ${topState} on nonterminal '${prod.lhs}'`;
        return true;
      }

      this.stack.push(parentNode);
      this.stack.push(gotoTarget);
      
      this.recordDerivationStep();
      return true;
    }

    if (action.type === 'Accept') {
      this.status = 'accepted';
      
      // Stack should have [0, S, AcceptState]
      // Pop AcceptState
      this.stack.pop();
      // Pop S
      this.tree = this.stack.pop() as SyntaxTreeNode;
      
      return true;
    }

    return false;
  }
}
