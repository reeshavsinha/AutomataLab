import React from 'react';
import { useParserStore } from '@/store/parserStore';

export function DerivationPanel() {
  const { simulation, algorithm } = useParserStore();
  
  if (!simulation || simulation.derivationSteps.length === 0) {
    return (
      <div style={{
        height: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'var(--text-muted)',
        fontFamily: 'var(--font-mono)',
        fontSize: '0.8rem',
        background: 'var(--bg-primary)'
      }}>
        Run the parser to see derivation
      </div>
    );
  }

  const isLR = algorithm !== 'LL1';
  // LR generates derivation steps bottom-up (input -> S). We want to display top-down (S -> input).
  const steps = isLR ? [...simulation.derivationSteps].reverse() : simulation.derivationSteps;

  return (
    <div style={{
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--bg-primary)',
      borderLeft: '1px solid var(--border-subtle)',
      overflow: 'hidden'
    }}>
      {/* Header */}
      <div style={{
        padding: '4px 8px',
        background: 'var(--bg-secondary)',
        borderBottom: '1px solid var(--border-subtle)',
        flexShrink: 0,
        height: '28px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        <span style={{
          fontSize: '0.68rem',
          fontWeight: 700,
          color: 'var(--text-muted)',
          letterSpacing: '0.08em',
          fontFamily: 'var(--font-mono)'
        }}>
          {isLR ? 'RIGHTMOST DERIVATION' : 'LEFTMOST DERIVATION'}
        </span>
      </div>

      {/* Content */}
      <div style={{
        flex: 1,
        overflowY: 'auto',
        padding: '8px'
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {steps.map((step, idx) => (
            <div key={idx} style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontFamily: 'var(--font-mono)',
              fontSize: '0.8rem',
              color: 'var(--text-primary)'
            }}>
              <span style={{ color: 'var(--text-muted)', minWidth: '24px', textAlign: 'right' }}>
                {idx === 0 ? '' : '⇒'}
              </span>
              <div style={{
                background: 'var(--bg-secondary)',
                padding: '4px 8px',
                borderRadius: '4px',
                border: '1px solid var(--border-subtle)'
              }}>
                {step.length === 0 ? 'ε' : step.join(' ')}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
