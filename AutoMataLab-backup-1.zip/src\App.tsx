// ============================================================
// App.tsx — Root component. Renders the application shell.
// ============================================================

import { useState, useEffect } from 'react';
import WorkspaceHub from './components/layout/WorkspaceHub';
import { MachineWorkspace } from './components/workspaces/MachineWorkspace';
import { GrammarWorkspace } from './components/workspaces/GrammarWorkspace';
import { ParserWorkspace } from './components/workspaces/ParserWorkspace';
import { RegexWorkspace } from './components/workspaces/RegexWorkspace';

import { useUIStore } from '@/store/uiStore'
import { useMachineStore } from '@/store/machineStore'
import MenuBar from '@/components/layout/MenuBar'
import ToastContainer from '@/components/layout/ToastContainer'
import UpdateBanner from '@/components/layout/UpdateBanner'
import UnsavedChangesGuard from '@/components/layout/UnsavedChangesGuard'
import HelpModal from '@/components/layout/HelpModal'
import ExportModal from '@/components/layout/ExportModal'
import ConversionsModal from '@/components/conversions/ConversionsModal'
import BatchRunnerModal from '@/components/controls/BatchRunnerModal'
import AnalysisModal from '@/components/analysis/AnalysisModal'
import { useGrammarStore } from '@/store/grammarStore'
import { useParserStore } from '@/store/parserStore'

const isSimulatorDeployment = import.meta.env.VITE_SIMULATOR_MODE === 'true';

function TabSyncListener() {
  const machine = useMachineStore((s) => s.machine);

  useEffect(() => {
    // When the active tab changes (or undo/redo alters the active tab),
    // sync the tab's grammar and parser state into the global stores.
    if (machine.type === 'CFG' || machine.type === 'CSG' || machine.type === 'REG' || machine.type === 'CFG_PARSER') {
      useGrammarStore.getState().setRawTextWithoutSync(machine.grammarText || '');
    }
    if (machine.type === 'CFG_PARSER') {
      useParserStore.getState().setAlgorithmWithoutSync(machine.parserAlgorithm || 'LL1');
      useParserStore.getState().setRawInputWithoutSync(machine.parserInput || '');
    }
  }, [machine.id, machine.grammarText, machine.parserAlgorithm, machine.parserInput, machine.type]);

  return null;
}

export default function App() {
  const isTauri = '__TAURI_INTERNALS__' in window;
  const isDemoMode = isSimulatorDeployment || window.location.href.includes('demo=true');

  const [route, setRoute] = useState(() => {
    if (!isDemoMode) {
      window.location.hash = '#/';
      return '#/';
    }
    return window.location.hash;
  });
  
  const theme = useUIStore((s) => s.theme)
  const activeModal = useUIStore((s) => s.activeModal)
  const closeModal = useUIStore((s) => s.closeModal)
  
  const activeMachineType = useMachineStore((s) => s.machine.type)

  // Reflect the active theme onto <html> so the CSS token overrides apply.
  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark')
  }, [theme])

  useEffect(() => {
    const handleHashChange = () => setRoute(window.location.hash)
    window.addEventListener('hashchange', handleHashChange)
    return () => window.removeEventListener('hashchange', handleHashChange)
  }, [isTauri, isDemoMode])

  // Record the active tab's preferred route ONLY when the route itself changes
  // (not when the user switches tabs, which would corrupt other tabs' saved routes).
  useEffect(() => {
    if (!route || route === '#' || route === '#/') return;
    const state = useMachineStore.getState();
    const machineId = state.machine.id;
    if (route === '#/machine' || route === '#/grammar' || route === '#/parser' || route === '#/regex') {
      if (state.tabRoutes[machineId] !== route) {
        useMachineStore.setState((s) => ({
          tabRoutes: { ...s.tabRoutes, [machineId]: route }
        }));
      }
    }
  }, [route]);

  // Anti-Trap: when the active tab TYPE changes (tab switch), redirect to the
  // correct workspace route for that type if we're on the wrong one.
  useEffect(() => {
    if (route === '' || route === '#' || route === '#/') return;

    const state = useMachineStore.getState();
    const machineId = state.machine.id;
    const preferredRoute = state.tabRoutes[machineId];

    const isParser = activeMachineType === 'CFG_PARSER';
    const isGrammar = activeMachineType === 'CFG' || activeMachineType === 'CSG';
    const isRegex = activeMachineType === 'REG';
    const isMachine = activeMachineType === 'DFA' || activeMachineType === 'NFA' || activeMachineType === 'ENFA' || activeMachineType === 'DPDA' || activeMachineType === 'NPDA' || activeMachineType === 'TM' || activeMachineType === 'LBA';

    if (isParser && route !== '#/parser') {
      window.location.hash = '#/parser';
    } else if (isGrammar && route !== '#/grammar') {
      window.location.hash = preferredRoute === '#/grammar' ? '#/grammar' : '#/grammar';
    } else if (isRegex && route !== '#/regex') {
      window.location.hash = '#/regex';
    } else if (isMachine && route !== '#/machine') {
      window.location.hash = '#/machine';
    }
  }, [activeMachineType, route]);

  // -----------------------------------------------------
  // Route dispatch
  // -----------------------------------------------------
  let content = null;

  if (isDemoMode) {
    content = <MachineWorkspace isDemoMode={true} />;
  } else if (route === '' || route === '#/') {
    content = <WorkspaceHub />;
  } else if (route === '#/machine') {
    content = <MachineWorkspace />;
  } else if (route === '#/grammar') {
    content = <GrammarWorkspace />;
  } else if (route === '#/regex') {
    content = <RegexWorkspace />;
  } else if (route === '#/parser') {
    content = <ParserWorkspace />;
  } else {
    // Fallback or legacy route
    content = <WorkspaceHub />;
  }

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100vh',
      width: '100vw',
      overflow: 'hidden',
      background: 'var(--bg-primary)',
    }}>
      {/* Global Hoisted Singletons */}
      {!isDemoMode && <MenuBar />}
      <TabSyncListener />
      
      {/* Main Workspace Content */}
      {content}

      <ToastContainer />
      <UpdateBanner />
      <UnsavedChangesGuard />

      {/* Modals */}
      {activeModal === 'help' && <HelpModal onClose={closeModal} />}
      {activeModal === 'export' && <ExportModal onClose={closeModal} />}
      {activeModal === 'convert' && <ConversionsModal onClose={closeModal} />}
      {activeModal === 'batch' && <BatchRunnerModal onClose={closeModal} />}
      {activeModal === 'analysis' && <AnalysisModal onClose={closeModal} />}
    </div>
  );
}
