import React from 'react';
import { useParserStore } from '@/store/parserStore';

export function StackViewerPanel() {
  const { simulation } = useParserStore();
  const status = simulation?.status ?? 'idle';
  const errorMsg = simulation?.errorMsg ?? null;
  const stack = simulation?.stack ?? [];

  // Stack entries displayed top-to-bottom (latest item at top)
  // stack array: [bottom, ..., top] so we display reversed
  const displayStack = [...stack].reverse();

  const renderItem = (node: any, index: number, isTop: boolean) => {
    if (typeof node === 'number') {
      return (
        <div
          key={`state_${index}`}
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            height: '28px',
            background: isTop ? 'rgba(96,165,250,0.15)' : 'transparent',
            borderBottom: '1px solid var(--border-subtle)',
            color: isTop ? 'var(--blue-400)' : 'var(--text-secondary)',
            fontFamily: 'var(--font-mono)',
            fontSize: '0.78rem',
            fontWeight: isTop ? 700 : 400,
            paddingLeft: '8px',
            paddingRight: '8px'
          }}
        >
          {node}
        </div>
      );
    }

    return (
      <div
        key={`sym_${node.id}_${index}`}
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          height: '28px',
          background: isTop ? 'rgba(249,115,22,0.12)' : 'transparent',
          borderBottom: '1px solid var(--border-subtle)',
          color: isTop ? 'var(--orange-400)' : 'var(--text-primary)',
          fontFamily: 'var(--font-mono)',
          fontSize: '0.78rem',
          fontWeight: isTop ? 700 : 400
        }}
      >
        {node.symbol}
      </div>
    );
  };

  return (
    <div style={{
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--bg-primary)',
      borderLeft: '1px solid var(--border-subtle)',
      overflow: 'hidden'
    }}>
      {/* Header */}
      <div style={{
        padding: '4px 8px',
        background: 'var(--bg-secondary)',
        borderBottom: '1px solid var(--border-subtle)',
        flexShrink: 0,
        height: '28px',
        display: 'flex',
        alignItems: 'center',
        gap: '8px'
      }}>
        <span style={{
          fontSize: '0.68rem',
          fontWeight: 700,
          color: 'var(--text-muted)',
          letterSpacing: '0.08em',
          fontFamily: 'var(--font-mono)'
        }}>
          STACK
        </span>
        {stack.length > 0 && (
          <span style={{
            fontSize: '0.68rem',
            color: 'var(--text-muted)',
            fontFamily: 'var(--font-mono)'
          }}>
            (State, Symbol)
          </span>
        )}
      </div>

      {/* Error banner */}
      {(status === 'error' || status === 'rejected') && errorMsg && (
        <div style={{
          padding: '4px 8px',
          background: 'var(--bg-error-subtle)',
          color: 'var(--text-error)',
          fontSize: '0.72rem',
          borderBottom: '1px solid var(--border-subtle)',
          flexShrink: 0,
          fontFamily: 'var(--font-mono)'
        }}>
          {errorMsg}
        </div>
      )}

      {/* Stack entries */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {stack.length === 0 ? (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            height: '100%',
            color: '#3a3f47',
            fontFamily: 'var(--font-mono)',
            fontSize: '0.75rem'
          }}>
            empty
          </div>
        ) : (
          displayStack.map((item, i) =>
            renderItem(item, i, i === 0)
          )
        )}
      </div>
    </div>
  );
}
