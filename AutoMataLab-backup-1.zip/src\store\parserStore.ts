import { useMemo } from 'react';
import { create } from 'zustand';
import { useGrammarStore } from './grammarStore';
import { useMachineStore } from './machineStore';
import { generateLL1Table, LL1Table } from '@/engines/parser/ll1';
import { generateLR0Table, LR0Table } from '@/engines/parser/lr0';
import { LL1Simulation, SyntaxTreeNode, ParserStatus } from '@/engines/parser/ll1Simulation';
import { LRSimulation } from '@/engines/parser/lrSimulation';
import { generateSLR1Table } from '@/engines/parser/slr1';
import { generateCLR1Table } from '@/engines/parser/clr1';
import { generateLALR1Table } from '@/engines/parser/lalr1';
import { tokenizeGrammarString } from '@/engines/grammar/parser';
import { CYKSimulation } from '@/engines/parser/cyk';
import { EarleySimulation } from '@/engines/parser/earley';
import { BacktrackingSimulation } from '@/engines/parser/backtracking';

export function useLL1Table(): LL1Table | null {
  const { cfg, analysis } = useGrammarStore();

  return useMemo(() => {
    if (!cfg || !analysis) return null;
    try {
      return generateLL1Table(cfg, analysis);
    } catch (e) {
      console.error("Failed to generate LL(1) table", e);
      return null;
    }
  }, [cfg, analysis]);
}

export function useLR0Table(): LR0Table | null {
  const { cfg } = useGrammarStore();

  return useMemo(() => {
    if (!cfg) return null;
    try {
      return generateLR0Table(cfg);
    } catch (e) {
      console.error("Failed to generate LR(0) table", e);
      return null;
    }
  }, [cfg]);
}

export function useSLR1Table(): LR0Table | null {
  const { cfg, analysis } = useGrammarStore();

  return useMemo(() => {
    if (!cfg || !analysis) return null;
    try {
      return generateSLR1Table(cfg, analysis);
    } catch (e) {
      console.error("Failed to generate SLR(1) table", e);
      return null;
    }
  }, [cfg, analysis]);
}

export function useCLR1Table(): LR0Table | null {
  const { cfg, analysis } = useGrammarStore();

  return useMemo(() => {
    if (!cfg || !analysis) return null;
    try {
      return generateCLR1Table(cfg, analysis);
    } catch (e) {
      console.error("Failed to generate CLR(1) table", e);
      return null;
    }
  }, [cfg, analysis]);
}

export function useLALR1Table(): LR0Table | null {
  const { cfg, analysis } = useGrammarStore();

  return useMemo(() => {
    if (!cfg || !analysis) return null;
    try {
      return generateLALR1Table(cfg, analysis);
    } catch (e) {
      console.error("Failed to generate LALR(1) table", e);
      return null;
    }
  }, [cfg, analysis]);
}

interface ParserSimulationState {
  algorithm: string;
  setAlgorithm: (alg: string) => void;
  setAlgorithmWithoutSync: (alg: string) => void;
  rawInput: string;
  setRawInput: (input: string) => void;
  setRawInputWithoutSync: (input: string) => void;
  tokens: string[];
  simulation: LL1Simulation | LRSimulation | CYKSimulation | EarleySimulation | BacktrackingSimulation | null;
  currentStep: number;
  maxStep: number;
  isPlaying: boolean;
  playSpeed: number;
  setIsPlaying: (playing: boolean) => void;
  setPlaySpeed: (speed: number) => void;
  initializeSim: () => void;
  seekToStep: (step: number) => void;
  stepSim: () => void;
  stepBack: () => void;
  seekToStart: () => void;
  seekToEnd: () => void;
  resetSim: () => void;
}

export const useParserStore = create<ParserSimulationState>((set, get) => ({
  algorithm: 'LL1',
  setAlgorithm: (alg) => {
    useMachineStore.setState((s) => {
      const tabs = [...s.tabs];
      const active = tabs[s.activeTabIndex];
      if (active && active.type === 'CFG_PARSER') {
        tabs[s.activeTabIndex] = { ...active, parserAlgorithm: alg };
      }
      return { tabs, machine: tabs[s.activeTabIndex], dirtyTabs: { ...s.dirtyTabs, [active.id]: true } };
    });
    get().setAlgorithmWithoutSync(alg);
  },
  setAlgorithmWithoutSync: (alg) => set({ algorithm: alg, simulation: null, currentStep: 0, maxStep: 0, isPlaying: false }),
  rawInput: '',
  tokens: [],
  simulation: null,
  currentStep: 0,
  maxStep: 0,
  isPlaying: false,
  playSpeed: 1,

  setIsPlaying: (playing) => set({ isPlaying: playing }),
  setPlaySpeed: (speed) => set({ playSpeed: speed }),

  setRawInput: (input: string) => {
    useMachineStore.setState((s) => {
      const tabs = [...s.tabs];
      const active = tabs[s.activeTabIndex];
      if (active && active.type === 'CFG_PARSER') {
        tabs[s.activeTabIndex] = { ...active, parserInput: input };
      }
      return { tabs, machine: tabs[s.activeTabIndex], dirtyTabs: { ...s.dirtyTabs, [active.id]: true } };
    });
    get().setRawInputWithoutSync(input);
  },

  setRawInputWithoutSync: (input: string) => {
    const { cfg } = useGrammarStore.getState();
    const terminals = cfg ? cfg.terminals : new Set<string>();
    
    const sortedTerminals = Array.from(terminals).sort((a, b) => b.length - a.length);
    const tokens: string[] = [];
    let remaining = input.trim();
    
    while (remaining.length > 0) {
      remaining = remaining.trimStart();
      if (remaining.length === 0) break;
      
      let matched = false;
      for (const t of sortedTerminals) {
        if (remaining.startsWith(t)) {
          tokens.push(t);
          remaining = remaining.substring(t.length);
          matched = true;
          break;
        }
      }
      
      if (!matched) {
        tokens.push(remaining[0]);
        remaining = remaining.substring(1);
      }
    }

    set({ rawInput: input, tokens, simulation: null, currentStep: 0, maxStep: 0, isPlaying: false });
  },

  initializeSim: () => {
    const { tokens, algorithm } = get();
    const { cfg, analysis } = useGrammarStore.getState();
    if (!cfg) return;

    let sim: LL1Simulation | LRSimulation | CYKSimulation | EarleySimulation | BacktrackingSimulation | null = null;
    if (algorithm === 'LL1') {
      if (!analysis) return;
      const table = generateLL1Table(cfg, analysis);
      if (table.hasConflict) return;
      sim = new LL1Simulation(cfg, table);
    } else if (algorithm === 'LR0') {
      const table = generateLR0Table(cfg);
      if (table.hasConflict) return;
      sim = new LRSimulation(cfg, table);
    } else if (algorithm === 'SLR1') {
      if (!analysis) return;
      const table = generateSLR1Table(cfg, analysis);
      if (table.hasConflict) return;
      sim = new LRSimulation(cfg, table);
    } else if (algorithm === 'CLR1') {
      if (!analysis) return;
      const table = generateCLR1Table(cfg, analysis);
      if (table.hasConflict) return;
      sim = new LRSimulation(cfg, table);
    } else if (algorithm === 'LALR1') {
      if (!analysis) return;
      const table = generateLALR1Table(cfg, analysis);
      if (table.hasConflict) return;
      sim = new LRSimulation(cfg, table);
    } else if (algorithm === 'CYK') {
      sim = new CYKSimulation(cfg);
    } else if (algorithm === 'EARLEY') {
      sim = new EarleySimulation(cfg);
    } else if (algorithm === 'BACKTRACKING') {
      sim = new BacktrackingSimulation(cfg);
    } else {
      return;
    }

    if (sim) {
      sim.initialize(tokens);
      set({ simulation: sim, currentStep: 0, maxStep: 0, isPlaying: false });
    }
  },

  seekToStep: (targetStep) => {
    const { tokens, algorithm } = get();
    const { cfg, analysis } = useGrammarStore.getState();
    if (!cfg) return;

    let sim: LL1Simulation | LRSimulation | CYKSimulation | EarleySimulation | BacktrackingSimulation | null = null;
    if (algorithm === 'LL1') {
      if (!analysis) return;
      const table = generateLL1Table(cfg, analysis);
      if (table.hasConflict) return;
      sim = new LL1Simulation(cfg, table);
    } else if (algorithm === 'LR0') {
      const table = generateLR0Table(cfg);
      if (table.hasConflict) return;
      sim = new LRSimulation(cfg, table);
    } else if (algorithm === 'SLR1') {
      if (!analysis) return;
      const table = generateSLR1Table(cfg, analysis);
      if (table.hasConflict) return;
      sim = new LRSimulation(cfg, table);
    } else if (algorithm === 'CLR1') {
      if (!analysis) return;
      const table = generateCLR1Table(cfg, analysis);
      if (table.hasConflict) return;
      sim = new LRSimulation(cfg, table);
    } else if (algorithm === 'LALR1') {
      if (!analysis) return;
      const table = generateLALR1Table(cfg, analysis);
      if (table.hasConflict) return;
      sim = new LRSimulation(cfg, table);
    } else if (algorithm === 'CYK') {
      sim = new CYKSimulation(cfg);
    } else if (algorithm === 'EARLEY') {
      sim = new EarleySimulation(cfg);
    } else if (algorithm === 'BACKTRACKING') {
      sim = new BacktrackingSimulation(cfg);
    } else {
      return;
    }

    if (sim) {
      sim.initialize(tokens);
      let steps = 0;
      while (steps < targetStep) {
        if (!sim.step()) break;
        steps++;
      }
      set({ simulation: sim, currentStep: steps, maxStep: Math.max(get().maxStep, steps) });
    }
  },

  stepSim: () => {
    const { currentStep } = get();
    get().seekToStep(currentStep + 1);
  },

  stepBack: () => {
    const { currentStep } = get();
    if (currentStep > 0) {
      get().seekToStep(currentStep - 1);
    }
  },

  seekToStart: () => {
    get().seekToStep(0);
  },

  seekToEnd: () => {
    // Arbitrary large number to run to end (capped by engine limits)
    get().seekToStep(1000);
    set({ isPlaying: false });
  },

  runSimToEnd: () => {
    get().seekToEnd();
  },
  
  resetSim: () => {
    set({ simulation: null, currentStep: 0, maxStep: 0, isPlaying: false });
  }
}));
