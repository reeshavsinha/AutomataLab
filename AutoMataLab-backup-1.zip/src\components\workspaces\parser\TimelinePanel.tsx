import React, { useEffect, useRef } from 'react';
import { useParserStore } from '@/store/parserStore';

const BTN_BASE: React.CSSProperties = {
  background: 'transparent',
  border: '1px solid var(--border-default)',
  borderRadius: '3px',
  padding: '2px 7px',
  cursor: 'pointer',
  color: 'var(--text-primary)',
  fontFamily: 'var(--font-mono)',
  fontSize: '0.72rem',
  fontWeight: 600,
  lineHeight: '18px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  minWidth: '24px'
};

export function TimelinePanel() {
  const {
    simulation,
    currentStep,
    maxStep,
    isPlaying,
    playSpeed,
    setIsPlaying,
    setPlaySpeed,
    seekToStep,
    stepBack,
    stepSim,
    seekToStart,
    seekToEnd,
    resetSim
  } = useParserStore();

  const timelineRef = useRef<HTMLDivElement>(null);
  const status = simulation?.status ?? 'idle';
  const isDone = status === 'accepted' || status === 'rejected' || status === 'error';

  // Auto-play interval
  useEffect(() => {
    let interval: any = null;
    if (isPlaying && !isDone) {
      const speedMs = 1000 / playSpeed;
      interval = setInterval(() => { stepSim(); }, speedMs);
    } else if (isDone && isPlaying) {
      setIsPlaying(false);
    }
    return () => clearInterval(interval);
  }, [isPlaying, isDone, playSpeed, stepSim, setIsPlaying]);

  // Auto-scroll timeline to active step
  useEffect(() => {
    if (timelineRef.current) {
      const active = timelineRef.current.querySelector('[data-active="true"]') as HTMLElement;
      if (active) {
        active.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      }
    }
  }, [currentStep]);

  const statusColor =
    status === 'accepted' ? '#4ade80' :
    status === 'error' || status === 'rejected' ? '#f87171' :
    '#fb923c';

  const statusLabel =
    status === 'idle' ? '' :
    status === 'running' ? 'Running' :
    status.charAt(0).toUpperCase() + status.slice(1);

  const speedOptions = [0.5, 1, 2, 4];

  return (
    <div style={{
      flexShrink: 0,
      background: 'var(--bg-primary)',
      borderTop: '1px solid var(--border-subtle)',
      display: 'flex',
      flexDirection: 'column'
    }}>
      {/* Row 1: History Timeline */}
      {maxStep > 0 && (
        <div
          ref={timelineRef}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '3px',
            padding: '4px 12px',
            overflowX: 'auto',
            borderBottom: '1px solid #21262d',
            background: 'var(--bg-secondary)',
            minHeight: '28px',
            scrollbarWidth: 'thin'
          }}
        >
          {Array.from({ length: maxStep + 1 }).map((_, i) => {
            const isActive = i === currentStep;
            const isPast = i < currentStep;
            return (
              <button
                key={i}
                data-active={isActive}
                onClick={() => seekToStep(i)}
                style={{
                  padding: '1px 8px',
                  borderRadius: '10px',
                  fontSize: '0.68rem',
                  fontWeight: isActive ? 700 : 400,
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                  fontFamily: 'var(--font-mono)',
                  flexShrink: 0,
                  background: isActive ? '#c9d1d9' : 'transparent',
                  color: isActive ? 'var(--bg-primary)' : (isPast ? 'var(--text-muted)' : 'var(--text-disabled)'),
                  border: isActive ? '1px solid #c9d1d9' : '1px solid #21262d',
                  transition: 'all 0.1s'
                }}
              >
                {i === 0 ? `Step 0` : `Step ${i}`}
              </button>
            );
          })}
        </div>
      )}

      {/* Row 2: Transport controls */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        padding: '4px 12px',
        gap: '6px',
        minHeight: '32px'
      }}>
        {/* Transport buttons */}
        <button onClick={seekToStart} style={BTN_BASE} title="Go to beginning">|&lt;&lt;</button>
        <button onClick={stepBack} style={BTN_BASE} title="One step back">&lt;</button>
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          style={{
            ...BTN_BASE,
            background: isPlaying ? '#21262d' : 'transparent',
            color: 'var(--text-primary)',
            minWidth: '28px'
          }}
          title={isPlaying ? 'Pause' : 'Play'}
        >
          {isPlaying ? '⏸' : '▶'}
        </button>
        <button onClick={stepSim} style={BTN_BASE} title="One step forward">&gt;</button>
        <button onClick={seekToEnd} style={BTN_BASE} title="Go to end">&gt;&gt;|</button>
        <button onClick={resetSim} style={BTN_BASE} title="Reset">↺</button>

        {/* Divider */}
        <div style={{ width: '1px', height: '16px', background: '#30363d', margin: '0 4px' }} />

        {/* Speed selector */}
        <span style={{
          fontSize: '0.68rem',
          color: 'var(--text-muted)',
          fontFamily: 'var(--font-mono)',
          marginRight: '2px'
        }}>
          SPEED
        </span>
        <div style={{ display: 'flex', gap: '2px' }}>
          {speedOptions.map(speed => (
            <button
              key={speed}
              onClick={() => setPlaySpeed(speed)}
              style={{
                ...BTN_BASE,
                background: playSpeed === speed ? 'var(--bg-secondary)' : 'transparent',
                color: playSpeed === speed ? 'var(--text-primary)' : 'var(--text-muted)',
                border: playSpeed === speed ? '1px solid var(--border-strong)' : '1px solid var(--border-subtle)',
                padding: '1px 5px',
                fontSize: '0.68rem'
              }}
            >
              {speed}x
            </button>
          ))}
        </div>

        {/* Step counter + status */}
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '8px' }}>
          {currentStep > 0 && (
            <span style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '0.72rem',
              color: 'var(--text-muted)'
            }}>
              step {currentStep}
            </span>
          )}
          {statusLabel && (
            <span style={{
              padding: '1px 8px',
              background: `${statusColor}18`,
              color: statusColor,
              border: `1px solid ${statusColor}`,
              borderRadius: '3px',
              fontSize: '0.68rem',
              fontWeight: 700,
              fontFamily: 'var(--font-mono)',
              letterSpacing: '0.06em'
            }}>
              {statusLabel}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
