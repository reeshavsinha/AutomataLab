// src/engines/grammar/parser.ts

import { CFG, Production, EPSILON } from './types';

export function isNonterminal(sym: string): boolean {
  // Enforced rule: Non-terminals are exactly ONE uppercase letter.
  return /^[A-Z]$/.test(sym);
}

// Tokenizes a string (LHS or RHS) completely ignoring whitespace,
// extracting single-letter NTs, contiguous terminals, and symbols.
export function tokenizeGrammarString(str: string): string[] {
  const tokens: string[] = [];
  // Match groups:
  // 1: Epsilon variations
  // 2: Single Uppercase Letter (Non-Terminal)
  // 3: Contiguous lowercase letters, numbers, underscores (Terminal)
  // 4: Any single other non-whitespace character (Symbol Terminal)
  const regex = /(\\epsilon|\\e|epsilon|''|""|ε)|([A-Z])|([a-z0-9_]+)|([^A-Za-z0-9_\s])/g;
  
  let match;
  while ((match = regex.exec(str)) !== null) {
    if (match[1]) {
      tokens.push(EPSILON);
    } else {
      tokens.push(match[0]);
    }
  }
  return tokens;
}

export function parseGrammarText(text: string): CFG {
  const lines = text.split('\n');
  const productions: Production[] = [];
  const nonterminals = new Set<string>();
  const terminals = new Set<string>();
  let startSymbol: string | null = null;

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('//') || trimmed.startsWith('#')) continue;

    // Split by -> or => or :
    const parts = trimmed.split(/->|=>|:/);
    if (parts.length < 2) continue; // Invalid line

    // LHS is the first token found before the arrow
    const lhsTokens = tokenizeGrammarString(parts[0]);
    if (lhsTokens.length === 0) continue;
    
    const lhs = lhsTokens[0]; // Take the first token as the LHS
    
    nonterminals.add(lhs);
    if (!startSymbol) {
      startSymbol = lhs;
    }

    const rhsPart = parts.slice(1).join('->').trim();
    const alternatives = rhsPart.split('|');

    for (const alt of alternatives) {
      const symbols = tokenizeGrammarString(alt);
      const rhs: string[] = [];

      if (symbols.length === 0) {
        // Empty RHS is treated as Epsilon
        rhs.push(EPSILON);
      } else {
        for (const sym of symbols) {
          rhs.push(sym);
          if (sym !== EPSILON) {
            if (isNonterminal(sym)) {
              nonterminals.add(sym);
            } else {
              terminals.add(sym);
            }
          }
        }
      }
      productions.push({ lhs, rhs });
    }
  }

  return {
    nonterminals,
    terminals,
    productions,
    startSymbol: startSymbol || '',
  };
}
