import { CFG } from '../grammar/types';
import { convertToCNF } from '../grammar/cnf';
import { ParserStatus } from './ll1Simulation';

export class CYKSimulation {
  public cfg: CFG;
  public cnfCfg: CFG;
  
  public input: string[] = [];
  public table: Set<string>[][] = [];
  public status: ParserStatus = 'idle';
  public errorMsg: string | null = null;
  
  public currentLength = 1;
  public currentStart = 0;
  
  // UI Compatibility fields
  public stack: any[] = [];
  public tree: any = null;
  public inputIndex: number = 0;
  public derivationSteps: any[][] = [];
  
  constructor(cfg: CFG) {
    this.cfg = cfg;
    // CYK requires CNF
    this.cnfCfg = convertToCNF(cfg);
  }

  public initialize(inputTokens: string[]) {
    this.input = inputTokens;
    this.status = 'running';
    this.errorMsg = null;
    this.currentLength = 1;
    this.currentStart = 0;
    
    const n = this.input.length;
    if (n === 0) {
      // Empty string case
      const startNullable = this.cfg.productions.some(p => p.lhs === this.cfg.startSymbol && (p.rhs.length === 0 || p.rhs[0] === 'ε'));
      this.status = startNullable ? 'accepted' : 'rejected';
      return;
    }

    // Initialize n x n table
    this.table = Array.from({ length: n }, () => Array.from({ length: n }, () => new Set<string>()));
  }

  public step(): boolean {
    if (this.status !== 'running') return false;
    
    const n = this.input.length;
    
    // Base case: substrings of length 1
    if (this.currentLength === 1) {
      const token = this.input[this.currentStart];
      for (const p of this.cnfCfg.productions) {
        if (p.rhs.length === 1 && p.rhs[0] === token) {
          this.table[this.currentStart][this.currentStart].add(p.lhs);
        }
      }
      
      this.currentStart++;
      if (this.currentStart >= n) {
        this.currentLength = 2;
        this.currentStart = 0;
      }
      return true;
    }
    
    // Recursive case: substrings of length > 1
    if (this.currentLength <= n) {
      const i = this.currentStart;
      const j = i + this.currentLength - 1;
      
      for (let k = i; k < j; k++) {
        const leftSet = this.table[i][k];
        const rightSet = this.table[k + 1][j];
        
        for (const p of this.cnfCfg.productions) {
          if (p.rhs.length === 2) {
            if (leftSet.has(p.rhs[0]) && rightSet.has(p.rhs[1])) {
              this.table[i][j].add(p.lhs);
            }
          }
        }
      }
      
      this.currentStart++;
      if (this.currentStart > n - this.currentLength) {
        this.currentLength++;
        this.currentStart = 0;
      }
      
      if (this.currentLength > n) {
        // Finished
        if (this.table[0][n - 1].has(this.cnfCfg.startSymbol)) {
          this.status = 'accepted';
        } else {
          this.status = 'rejected';
        }
      }
      return true;
    }
    
    return false;
  }
}
