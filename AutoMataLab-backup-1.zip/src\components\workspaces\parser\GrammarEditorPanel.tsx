import React, { useRef, useEffect } from 'react';
import { useGrammarStore } from '@/store/grammarStore';
import { useTraceabilityStore } from '@/store/traceabilityStore';

export function GrammarEditorPanel() {
  const { rawText, setRawText, cfg } = useGrammarStore();
  const { setFocusedProduction } = useTraceabilityStore();
  const textAreaRef = useRef<HTMLTextAreaElement>(null);
  const lineNumRef = useRef<HTMLDivElement>(null);

  const lines = rawText.split('\n');

  // Sync line number scroll with textarea scroll
  useEffect(() => {
    const ta = textAreaRef.current;
    const ln = lineNumRef.current;
    if (!ta || !ln) return;
    const sync = () => { ln.scrollTop = ta.scrollTop; };
    ta.addEventListener('scroll', sync);
    return () => ta.removeEventListener('scroll', sync);
  }, []);

  // Handle Tab key in textarea
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const ta = e.currentTarget;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const newVal = rawText.slice(0, start) + '  ' + rawText.slice(end);
      setRawText(newVal);
      setTimeout(() => { ta.selectionStart = ta.selectionEnd = start + 2; }, 0);
    }
  };

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      background: 'var(--bg-primary)',
      borderRight: '1px solid var(--border-subtle)',
      overflow: 'hidden',
      fontFamily: 'var(--font-mono)'
    }}>
      {/* Panel header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 8px',
        height: '28px',
        background: 'var(--bg-secondary)',
        borderBottom: '1px solid var(--border-subtle)',
        flexShrink: 0
      }}>
        <span style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', fontWeight: 600, letterSpacing: '0.04em' }}>
          GRAMMAR.CFG
        </span>
        <button
          onClick={() => {
            const ta = textAreaRef.current;
            if (!ta) { setRawText(rawText + '\nε'); return; }
            const start = ta.selectionStart ?? rawText.length;
            const end = ta.selectionEnd ?? rawText.length;
            const newVal = rawText.slice(0, start) + 'ε' + rawText.slice(end);
            setRawText(newVal);
            setTimeout(() => { ta.selectionStart = ta.selectionEnd = start + 1; ta.focus(); }, 0);
          }}
          style={{
            padding: '1px 6px',
            background: 'transparent',
            border: '1px solid var(--border-subtle)',
            borderRadius: '3px',
            cursor: 'pointer',
            color: 'var(--text-secondary)',
            fontSize: '0.68rem',
            fontFamily: 'var(--font-mono)'
          }}
        >
          Insert ε
        </button>
      </div>

      {/* Editor body: line numbers + textarea */}
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Line numbers */}
        <div
          ref={lineNumRef}
          style={{
            width: '32px',
            flexShrink: 0,
            background: 'var(--bg-primary)',
            borderRight: '1px solid var(--border-subtle)',
            padding: '8px 0',
            overflowY: 'hidden',
            userSelect: 'none',
            pointerEvents: 'none'
          }}
        >
          {lines.map((_, i) => (
            <div key={i} style={{
              height: '21px',
              lineHeight: '21px',
              textAlign: 'right',
              paddingRight: '6px',
              fontSize: '0.72rem',
              color: 'var(--text-muted)',
              fontFamily: 'var(--font-mono)'
            }}>
              {i + 1}
            </div>
          ))}
        </div>

        {/* Plain textarea — no overlay, no sync bugs */}
        <textarea
          ref={textAreaRef}
          value={rawText}
          onChange={e => setRawText(e.target.value)}
          onFocus={() => setFocusedProduction(null)}
          onKeyDown={handleKeyDown}
          spellCheck={false}
          placeholder={'E -> T Eprime\nEprime -> + T Eprime | ε\nT -> F Tprime\nTprime -> * F Tprime | ε\nF -> ( E ) | id'}
          style={{
            flex: 1,
            padding: '8px 8px',
            fontFamily: 'var(--font-mono)',
            fontSize: '0.8rem',
            lineHeight: '21px',
            color: 'var(--text-primary)',
            background: 'transparent',
            border: 'none',
            resize: 'none',
            outline: 'none',
            overflowY: 'auto',
            overflowX: 'hidden',
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-all',
            caretColor: 'var(--text-primary)'
          }}
        />
      </div>

      {/* Status footer */}
      <div style={{
        padding: '3px 8px',
        background: cfg
          ? 'var(--status-accept-soft)'
          : (rawText.trim() ? 'var(--status-reject-soft)' : 'transparent'),
        color: cfg ? 'var(--status-accept)' : (rawText.trim() ? 'var(--status-reject)' : 'var(--text-muted)'),
        fontSize: '0.68rem',
        fontWeight: 600,
        borderTop: '1px solid var(--border-subtle)',
        flexShrink: 0,
        fontFamily: 'var(--font-mono)'
      }}>
        {cfg
          ? `✓ Valid | ${cfg.productions.length} Prod | ${cfg.nonterminals.size} NT | ${cfg.terminals.size} T`
          : (rawText.trim() ? '✗ Invalid CFG' : '')
        }
      </div>
    </div>
  );
}
